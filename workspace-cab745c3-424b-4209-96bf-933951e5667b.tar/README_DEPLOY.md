# Panduan Deploy ke Vercel

## 📋 Prasyarat

1. Akun Vercel (gratis di vercel.com)
2. Akun GitHub/GitLab/Bitbucket
3. Database PostgreSQL (rekomendasi: Neon, Supabase, atau Prisma Cloud)

## 🚀 Langkah 1: Setup Database Production

### Opsi A: Menggunakan Neon (Gratis & Recommended)

1. Buka [neon.tech](https://neon.tech)
2. Sign up / Login
3. Buat project baru
4. Copy connection string
5. Format: `postgresql://[user]:[password]@[host]/[database]?sslmode=require`

### Opsi B: Menggunakan Supabase (Gratis)

1. Buka [supabase.com](https://supabase.com)
2. Buat project baru
3. Masuk ke Settings → Database
4. Copy Connection String
5. Pilih "URI" format
6. Ganti `[YOUR-PASSWORD]` dengan password database Anda

## 🚀 Langkah 2: Push ke GitHub

```bash
# 1. Initialize git jika belum
git init

# 2. Add semua file
git add .

# 3. Commit
git commit -m "Initial commit - SI Izin Penelitian BAKESBANGPOLDAGRI NTB"

# 4. Buat repository baru di GitHub

# 5. Connect ke GitHub
git remote add origin https://github.com/USERNAME/REPO-NAME.git

# 6. Push
git branch -M main
git push -u origin main
```

## 🚀 Langkah 3: Deploy ke Vercel

### Cara 1: Via Vercel CLI (Recommended)

```bash
# 1. Login ke Vercel
vercel login

# 2. Deploy
cd /home/z/my-project
vercel

# Ikuti instruksi:
# - Set up and deploy? Y
# - Link to existing project? N
# - Project name: si-izin-penelitian (atau nama lain)
# - In which directory is your code located? ./
# - Want to override settings? N
# - Which scope? Pilih scope Anda

# 3. Set Environment Variables
# Di Vercel Dashboard → Settings → Environment Variables
# Tambahkan:
# DATABASE_URL = (connection string dari database PostgreSQL)
```

### Cara 2: Via Vercel Dashboard

1. Buka [vercel.com](https://vercel.com)
2. Login atau Sign Up
3. Klik "Add New" → "Project"
4. Import dari GitHub
5. Pilih repository yang sudah di-push
6. Configure Project:
   - Framework Preset: Next.js
   - Root Directory: `./`
   - Build Command: `prisma generate && next build`
   - Output Directory: `.next`
   - Install Command: `bun install`

7. Environment Variables:
   - Klik "Environment Variables"
   - Tambahkan:
     - Name: `DATABASE_URL`
     - Value: (connection string PostgreSQL Anda)
     - Select: Production, Preview, Development

8. Klik "Deploy"

## 🚀 Langkah 4: Setup Database di Production

```bash
# Set environment variable untuk production
export DATABASE_URL="postgresql://user:password@host:5432/database"

# Push schema ke database production
bunx prisma db push

# Seed data (buat admin & pimpinan user)
bun run db:seed
```

Atau via Vercel CLI:

```bash
# Set database URL di Vercel
vercel env add DATABASE_URL production

# Masukkan connection string PostgreSQL Anda

# Push database schema
vercel env pull .env.local
bunx prisma db push
bun run db:seed
```

## 🚀 Langkah 5: Verifikasi Deployment

1. Buka URL yang diberikan Vercel (misal: `https://si-izin-penelitian.vercel.app`)
2. Coba login dengan:
   - Admin: `admin@bakesbang.ntbprov.go.id` / `admin123`
   - Pimpinan: `pimpinan@bakesbang.ntbprov.go.id` / `pimpinan123`

## 🔧 Troubleshooting

### Error: Database Connection Failed

**Solusi:**
- Pastikan `DATABASE_URL` sudah di-set di Vercel Environment Variables
- Pastikan database PostgreSQL sudah di-create
- Pastikan connection string format benar

### Error: Build Failed

**Solusi:**
- Cek build logs di Vercel Dashboard
- Pastikan semua dependencies terinstall
- Pastikan `prisma generate` berhasil

### Login Tidak Berhasil di Production

**Solusi:**
- Jalankan `bun run db:seed` dengan DATABASE_URL production
- Atau buat user admin/pimpinan manual di database production

## 📝 Catatan Penting

### SQLite Tidak Support di Vercel

Aplikasi ini menggunakan **SQLite** untuk development, tapi SQLite **TIDAK cocok** untuk Vercel (serverless). Untuk production:

**WAJIB** menggunakan database lain:
- ✅ PostgreSQL (Neon, Supabase, Prisma Cloud)
- ✅ MySQL (PlanetScale)
- ❌ SQLite (hanya untuk development lokal)

### File Upload di Production

File upload saat ini menggunakan local storage. Untuk production:
- Gunakan Vercel Blob Storage
- Atau AWS S3 / Cloudinary / Supabase Storage

## 🎯 Next Steps Setelah Deploy

1. Setup custom domain (opsional)
2. Setup analytics (Vercel Analytics)
3. Setup error tracking (Sentry)
4. Setup monitoring (Vercel Monitoring)
5. Backup database secara berkala

## 📞 Bantuan

- Vercel Docs: https://vercel.com/docs
- Prisma Docs: https://www.prisma.io/docs
- Neon Docs: https://neon.tech/docs
- Supabase Docs: https://supabase.com/docs
