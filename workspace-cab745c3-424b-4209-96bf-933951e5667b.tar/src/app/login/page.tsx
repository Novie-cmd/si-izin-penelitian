'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Lock, Mail, AlertCircle, Home, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'

export default function LoginPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const [formData, setFormData] = useState({
    email: 'admin@bakesbang.ntbprov.go.id',
    password: 'admin123',
  })

  const fillAdmin = () => {
    setFormData({
      email: 'admin@bakesbang.ntbprov.go.id',
      password: 'admin123',
    })
    setError('')
  }

  const fillPimpinan = () => {
    setFormData({
      email: 'pimpinan@bakesbang.ntbprov.go.id',
      password: 'pimpinan123',
    })
    setError('')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Login gagal')
      }

      localStorage.setItem('token', data.token)
      localStorage.setItem('user', JSON.stringify(data.user))

      if (data.user.role === 'ADMIN') {
        router.push('/admin/dashboard')
      } else if (data.user.role === 'PIMPINAN') {
        router.push('/pimpinan/dashboard')
      } else {
        router.push('/')
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
      <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10">
                <Home className="w-4 h-4 mr-2" />
                Beranda
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Login Sistem</h1>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-900" />
              </div>
              <CardTitle className="text-2xl">Login</CardTitle>
              <CardDescription>
                Masuk untuk mengakses dashboard Admin atau Pimpinan
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="admin@contoh.com"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      required
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-blue-900 hover:bg-blue-800"
                  size="lg"
                >
                  {loading ? 'Masuk...' : 'Masuk'}
                </Button>
              </form>

              <div className="mt-6 space-y-3">
                <p className="text-center text-sm font-medium text-slate-700">
                  Klik tombol di bawah untuk auto-fill:
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={fillAdmin}
                    className="bg-green-50 border-green-200 text-green-800 hover:bg-green-100"
                  >
                    🧑‍💼 Admin
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={fillPimpinan}
                    className="bg-purple-50 border-purple-200 text-purple-800 hover:bg-purple-100"
                  >
                    👨‍⚖️ Pimpinan
                  </Button>
                </div>
              </div>

              <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-800">
                  <strong>Akses Demo:</strong><br />
                  Admin: admin@bakesbang.ntbprov.go.id / admin123<br />
                  Pimpinan: pimpinan@bakesbang.ntbprov.go.id / pimpinan123
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="bg-slate-900 text-white mt-auto py-6">
        <div className="container mx-auto px-4 text-center text-slate-400 text-sm">
          © {new Date().getFullYear()} BAKESBANGPOLDAGRI NTB. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
