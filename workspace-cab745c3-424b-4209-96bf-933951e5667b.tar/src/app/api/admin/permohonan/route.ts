import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // Get all permohonan (except soft deleted)
    const permohonan = await db.permohonan.findMany({
      where: {
        deletedAt: null,
      },
      orderBy: {
        createdAt: 'desc',
      },
    })

    // Calculate stats
    const stats = {
      total: permohonan.length,
      menunggu: permohonan.filter(p => p.status === 'MENUNGGU_VERIFIKASI').length,
      menungguPersetujuan: permohonan.filter(p => p.status === 'MENUNGGU_PERSETUJUAN').length,
      disetujui: permohonan.filter(p => p.status === 'DISETUJUI').length,
      ditolak: permohonan.filter(p => p.status === 'DITOLAK').length,
    }

    return NextResponse.json({
      permohonan,
      stats,
    })
  } catch (error) {
    console.error('Get admin permohonan error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}
