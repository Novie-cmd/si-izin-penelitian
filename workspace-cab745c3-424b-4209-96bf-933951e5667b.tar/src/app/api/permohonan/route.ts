import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()

    // Extract form data
    const namaLengkap = formData.get('namaLengkap') as string
    const nik = formData.get('nik') as string
    const email = formData.get('email') as string
    const noHp = formData.get('noHp') as string
    const instansi = formData.get('instansi') as string
    const programStudi = formData.get('programStudi') as string
    const judulPenelitian = formData.get('judulPenelitian') as string
    const lokasiPenelitian = formData.get('lokasiPenelitian') as string
    const tanggalMulai = formData.get('tanggalMulai') as string
    const tanggalSelesai = formData.get('tanggalSelesai') as string
    const fileProposal = formData.get('fileProposal') as File
    const fileKtp = formData.get('fileKtp') as File
    const filePengantar = formData.get('filePengantar') as File

    // Validate required fields
    if (!namaLengkap || !nik || !email || !noHp || !instansi || !programStudi ||
        !judulPenelitian || !lokasiPenelitian || !tanggalMulai || !tanggalSelesai ||
        !fileProposal || !fileKtp || !filePengantar) {
      return NextResponse.json(
        { error: 'Semua field dan file harus diisi' },
        { status: 400 }
      )
    }

    // Validate file types (PDF only)
    const allowedTypes = ['application/pdf']
    if (!allowedTypes.includes(fileProposal.type) ||
        !allowedTypes.includes(fileKtp.type) ||
        !allowedTypes.includes(filePengantar.type)) {
      return NextResponse.json(
        { error: 'Hanya file PDF yang diperbolehkan' },
        { status: 400 }
      )
    }

    // Validate file size (max 5MB)
    const maxSize = 5 * 1024 * 1024
    if (fileProposal.size > maxSize || fileKtp.size > maxSize || filePengantar.size > maxSize) {
      return NextResponse.json(
        { error: 'Ukuran file maksimal 5MB' },
        { status: 400 }
      )
    }

    // Generate nomor registrasi
    const date = new Date()
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
    const nomorRegistrasi = `Izin-${year}${month}-${random}`

    // Create or get user
    let user = await db.user.findUnique({
      where: { email },
    })

    if (!user) {
      // Create new user with default password (for demo)
      const hashedPassword = await bcrypt.hash(nik, 10)
      user = await db.user.create({
        data: {
          email,
          password: hashedPassword,
          nama: namaLengkap,
          role: 'USER',
        },
      })
    }

    // Save files
    const uploadsDir = path.join(process.cwd(), 'public', 'uploads')
    await mkdir(uploadsDir, { recursive: true })

    const proposalFileName = `${nomorRegistrasi}_proposal.pdf`
    const ktpFileName = `${nomorRegistrasi}_ktp.pdf`
    const pengantarFileName = `${nomorRegistrasi}_pengantar.pdf`

    const proposalPath = path.join(uploadsDir, proposalFileName)
    const ktpPath = path.join(uploadsDir, ktpFileName)
    const pengantarPath = path.join(uploadsDir, pengantarFileName)

    const proposalBytes = await fileProposal.arrayBuffer()
    const ktpBytes = await fileKtp.arrayBuffer()
    const pengantarBytes = await filePengantar.arrayBuffer()

    await writeFile(proposalPath, Buffer.from(proposalBytes))
    await writeFile(ktpPath, Buffer.from(ktpBytes))
    await writeFile(pengantarPath, Buffer.from(pengantarBytes))

    // Create permohonan
    const permohonan = await db.permohonan.create({
      data: {
        nomorRegistrasi,
        userId: user.id,
        nik,
        namaLengkap,
        email,
        noHp,
        instansi,
        programStudi,
        judulPenelitian,
        lokasiPenelitian,
        tanggalMulai: new Date(tanggalMulai),
        tanggalSelesai: new Date(tanggalSelesai),
        status: 'MENUNGGU_VERIFIKASI',
        fileProposal: proposalFileName,
        fileKtp: ktpFileName,
        filePengantar: pengantarFileName,
      },
    })

    // Log aktivitas
    await db.logAktivitas.create({
      data: {
        userId: user.id,
        permohonanId: permohonan.id,
        aktivitas: 'AJUAN_PERMOHONAN',
        detail: `Pengajuan izin penelitian dengan nomor registrasi ${nomorRegistrasi}`,
      },
    })

    return NextResponse.json({
      success: true,
      nomorRegistrasi,
      message: 'Permohonan berhasil diajukan',
    })
  } catch (error) {
    console.error('Permohonan error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}

import bcrypt from 'bcryptjs'
