import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jsPDF from 'jspdf'
import QRCode from 'qrcode'

export async function GET(
  request: NextRequest,
  { params }: { params: { nomorRegistrasi: string } }
) {
  try {
    const permohonan = await db.permohonan.findUnique({
      where: {
        nomorRegistrasi: params.nomorRegistrasi,
      },
    })

    if (!permohonan) {
      return NextResponse.json(
        { error: 'Permohonan tidak ditemukan' },
        { status: 404 }
      )
    }

    if (permohonan.status !== 'DISETUJUI') {
      return NextResponse.json(
        { error: 'Permohonan belum disetujui' },
        { status: 400 }
      )
    }

    // Generate QR Code
    const qrData = JSON.stringify({
      nomorRegistrasi: permohonan.nomorRegistrasi,
      nomorSurat: permohonan.nomorSurat,
      status: permohonan.status,
    })

    const qrCodeDataURL = await QRCode.toDataURL(qrData, {
      width: 100,
      margin: 1,
    })

    // Create PDF
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    })

    // Set font (using built-in fonts)
    doc.setFont('helvetica', 'bold')

    // KOP SURAT
    // Garis atas
    doc.setLineWidth(0.5)
    doc.line(20, 20, 190, 20)

    // Judul instansi
    doc.setFontSize(14)
    doc.text('PEMERINTAH PROVINSI NUSA TENGGARA BARAT', 105, 28, { align: 'center' })
    doc.text('BADAN KESATUAN BANGSA DAN POLITIK DALAM NEGERI', 105, 35, { align: 'center' })

    doc.setFontSize(10)
    doc.setFont('helvetica', 'normal')
    doc.text('Jl. Majapahit No. 60, Mataram 83125, Nusa Tenggara Barat', 105, 42, { align: 'center' })
    doc.text('Telp: (0370) 633523, Email: bakesbang@ntbprov.go.id', 105, 47, { align: 'center' })

    // Garis bawah
    doc.setLineWidth(0.5)
    doc.line(20, 50, 190, 50)
    doc.setLineWidth(0.2)
    doc.line(20, 52, 190, 52)

    // JUDUL SURAT
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('SURAT IZIN PENELITIAN', 105, 70, { align: 'center' })

    // Nomor Surat
    doc.setFontSize(11)
    doc.setFont('helvetica', 'normal')
    doc.text(`Nomor: ${permohonan.nomorSurat}`, 105, 78, { align: 'center' })

    // Isi Surat
    let y = 95
    const leftMargin = 30
    const rightMargin = 180

    doc.setFontSize(11)

    const addText = (text: string, x: number, y: number) => {
      doc.text(text, x, y)
    }

    addText('Yang bertanda tangan di bawah ini Kepala Badan Kesatuan Bangsa dan Politik', leftMargin, y)
    y += 7
    addText('Dalam Negeri Provinsi Nusa Tenggara Barat, menerangkan bahwa:', leftMargin, y)
    y += 12

    addText('Nama Lengkap', leftMargin, y)
    addText(': ' + permohonan.namaLengkap, rightMargin, y)
    y += 8

    addText('NIK', leftMargin, y)
    addText(': ' + permohonan.nik, rightMargin, y)
    y += 8

    addText('Instansi / Universitas', leftMargin, y)
    addText(': ' + permohonan.instansi, rightMargin, y)
    y += 8

    addText('Program Studi', leftMargin, y)
    addText(': ' + permohonan.programStudi, rightMargin, y)
    y += 8

    addText('Judul Penelitian', leftMargin, y)
    y += 6

    // Wrap text for judul penelitian
    const splitTitle = doc.splitTextToSize(permohonan.judulPenelitian, 110)
    addText(': ', leftMargin, y)
    doc.text(splitTitle, leftMargin + 10, y)
    y += splitTitle.length * 6 + 2

    addText('Lokasi Penelitian', leftMargin, y)
    y += 6

    // Wrap text for lokasi
    const splitLokasi = doc.splitTextToSize(permohonan.lokasiPenelitian, 110)
    addText(': ', leftMargin, y)
    doc.text(splitLokasi, leftMargin + 10, y)
    y += splitLokasi.length * 6 + 2

    addText('Waktu Pelaksanaan', leftMargin, y)
    const tanggalMulai = new Date(permohonan.tanggalMulai).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
    const tanggalSelesai = new Date(permohonan.tanggalSelesai).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
    addText(': ' + tanggalMulai + ' s.d. ' + tanggalSelesai, rightMargin, y)
    y += 15

    // Paragraf
    doc.setFont('helvetica', 'normal')
    const paragraf = `Diberikan izin untuk melakukan penelitian di wilayah Provinsi Nusa Tenggara Barat dengan ketentuan sebagai berikut:`
    const splitPara = doc.splitTextToSize(paragraf, 150)
    doc.text(splitPara, leftMargin, y)
    y += splitPara.length * 6 + 5

    // Ketentuan
    const ketentuan = [
      '1. Wajib melaporkan kehadiran dan hasil penelitian kepada instansi terkait.',
      '2. Dilarang melakukan kegiatan di luar pokok penelitian yang telah disetujui.',
      '3. Wajib menjunjung tinggi etika penelitian dan norma yang berlaku.',
      '4. Menghormati adat istiadat dan kearifan lokal masyarakat setempat.',
      '5. Segala biaya yang timbul menjadi tanggung jawab peneliti.',
    ]

    doc.setFont('helvetica', 'normal')
    ketentuan.forEach((ket) => {
      const splitKet = doc.splitTextToSize(ket, 150)
      doc.text(splitKet, leftMargin + 5, y)
      y += splitKet.length * 6
    })

    y += 10

    // Penutup
    const penutup = 'Demikian surat izin ini dibuat untuk dipergunakan sebagaimana mestinya.'
    const splitPenutup = doc.splitTextToSize(penutup, 150)
    doc.text(splitPenutup, leftMargin, y)
    y += splitPenutup.length * 6 + 15

    // Tanda Tangan
    const tanggalTerbit = permohonan.tanggalApprove
      ? new Date(permohonan.tanggalApprove).toLocaleDateString('id-ID', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })
      : new Date().toLocaleDateString('id-ID', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })

    doc.text('Mataram, ' + tanggalTerbit, 145, y)
    y += 6
    doc.text('Kepala Badan Kesatuan Bangsa dan', 145, y)
    y += 6
    doc.text('Politik Dalam Negeri', 145, y)
    y += 6
    doc.text('Provinsi Nusa Tenggara Barat', 145, y)
    y += 25

    // Tanda tangan placeholder
    doc.setFontSize(11)
    doc.text('(..........................................)', 145, y)
    y += 6
    doc.text('NIP. ..........................................', 145, y)

    // QR Code di pojok kanan bawah
    doc.addImage(qrCodeDataURL, 'PNG', 150, 240, 40, 40)
    doc.setFontSize(8)
    doc.text('Scan QR untuk validasi', 170, 283, { align: 'center' })

    // Generate PDF buffer
    const pdfBuffer = Buffer.from(doc.output('arraybuffer'))

    // Log aktivitas
    await db.logAktivitas.create({
      data: {
        userId: permohonan.userId,
        permohonanId: permohonan.id,
        aktivitas: 'DOWNLOAD_SURAT',
        detail: `Download surat izin ${permohonan.nomorRegistrasi}`,
      },
    })

    return new NextResponse(pdfBuffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="surat-izin-${permohonan.nomorRegistrasi}.pdf"`,
      },
    })
  } catch (error) {
    console.error('Download surat error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat generate PDF' },
      { status: 500 }
    )
  }
}
