import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { nomorRegistrasi: string } }
) {
  try {
    const permohonan = await db.permohonan.findUnique({
      where: {
        nomorRegistrasi: params.nomorRegistrasi,
      },
    })

    if (!permohonan) {
      return NextResponse.json(
        { error: 'Data tidak ditemukan' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      id: permohonan.id,
      nomorRegistrasi: permohonan.nomorRegistrasi,
      namaLengkap: permohonan.namaLengkap,
      judulPenelitian: permohonan.judulPenelitian,
      instansi: permohonan.instansi,
      lokasiPenelitian: permohonan.lokasiPenelitian,
      tanggalMulai: permohonan.tanggalMulai,
      tanggalSelesai: permohonan.tanggalSelesai,
      status: permohonan.status,
      catatanAdmin: permohonan.catatanAdmin,
      catatanPimpinan: permohonan.catatanPimpinan,
      nomorSurat: permohonan.nomorSurat,
      tanggalApprove: permohonan.tanggalApprove,
      createdAt: permohonan.createdAt,
    })
  } catch (error) {
    console.error('Get permohonan error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}
