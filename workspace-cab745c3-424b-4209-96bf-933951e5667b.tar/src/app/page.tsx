'use client'

import Link from 'next/link'
import { FileText, SearchCheck, ShieldCheck, Users, BarChart3, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <h1 className="text-2xl md:text-3xl font-bold">
                BAKESBANGPOLDAGRI NTB
              </h1>
              <p className="text-blue-100 text-sm md:text-base">
                Sistem Informasi Pelayanan Izin Penelitian
              </p>
            </div>
            <nav className="flex gap-3">
              <Link href="/tracking">
                <Button variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white/30">
                  <SearchCheck className="w-4 h-4 mr-2" />
                  Cek Status
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-white text-blue-900 hover:bg-blue-50">
                  Login
                </Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-12 md:py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-slate-800 mb-6">
            Layanan Pengajuan Izin Penelitian Online
          </h2>
          <p className="text-lg md:text-xl text-slate-600 mb-8">
            Permudah proses pengajuan izin penelitian di lingkungan Pemerintah Provinsi Nusa Tenggara Barat
            secara cepat, transparan, dan efisien.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/pengajuan">
              <Button size="lg" className="bg-blue-900 hover:bg-blue-800 text-white px-8 py-6 text-lg">
                <FileText className="w-5 h-5 mr-2" />
                Ajukan Izin Penelitian
              </Button>
            </Link>
            <Link href="/tracking">
              <Button size="lg" variant="outline" className="px-8 py-6 text-lg border-2">
                <SearchCheck className="w-5 h-5 mr-2" />
                Cek Status Permohonan
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-2xl md:text-3xl font-bold text-center text-slate-800 mb-12">
            Fitur Layanan
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow border-t-4 border-t-blue-900">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-blue-900" />
                </div>
                <CardTitle>Pengajuan Online</CardTitle>
                <CardDescription>
                  Ajukan permohonan izin penelitian secara online kapan saja dan di mana saja
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow border-t-4 border-t-green-600">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>Verifikasi Cepat</CardTitle>
                <CardDescription>
                  Proses verifikasi dan persetujuan yang transparan dan terstruktur
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow border-t-4 border-t-purple-600">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <ShieldCheck className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle>Keamanan Terjamin</CardTitle>
                <CardDescription>
                  Sistem keamanan dengan role-based access control dan enkripsi data
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow border-t-4 border-t-orange-500">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                  <SearchCheck className="w-6 h-6 text-orange-500" />
                </div>
                <CardTitle>Tracking Real-time</CardTitle>
                <CardDescription>
                  Pantau status permohonan Anda secara real-time
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow border-t-4 border-teal-500">
              <CardHeader>
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-teal-500" />
                </div>
                <CardTitle>Dashboard Monitoring</CardTitle>
                <CardDescription>
                  Monitoring dan kontrol data izin melalui dashboard yang komprehensif
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow border-t-4 border-pink-500">
              <CardHeader>
                <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-pink-500" />
                </div>
                <CardTitle>Multi-Role Access</CardTitle>
                <CardDescription>
                  Sistem hak akses untuk User, Admin, dan Pimpinan
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Workflow Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h3 className="text-2xl md:text-3xl font-bold text-center text-slate-800 mb-12">
            Alur Pengajuan Izin
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-900 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">Isi Formulir</h4>
              <p className="text-sm text-slate-600">Lengkapi data dan upload dokumen</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-800 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">Verifikasi</h4>
              <p className="text-sm text-slate-600">Admin memverifikasi dokumen</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-700 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">Persetujuan</h4>
              <p className="text-sm text-slate-600">Pimpinan menyetujui izin</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                4
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">Terbit Izin</h4>
              <p className="text-sm text-slate-600">Download surat izin resmi</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white mt-auto">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h5 className="font-bold text-lg mb-4">BAKESBANGPOLDAGRI NTB</h5>
              <p className="text-slate-300 text-sm">
                Badan Kesatuan Bangsa dan Politik Dalam Negeri<br />
                Provinsi Nusa Tenggara Barat
              </p>
            </div>
            <div>
              <h5 className="font-bold text-lg mb-4">Layanan</h5>
              <ul className="space-y-2 text-slate-300 text-sm">
                <li><Link href="/pengajuan" className="hover:text-white transition-colors">Pengajuan Izin</Link></li>
                <li><Link href="/tracking" className="hover:text-white transition-colors">Cek Status</Link></li>
                <li><Link href="/login" className="hover:text-white transition-colors">Login Sistem</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-lg mb-4">Kontak</h5>
              <p className="text-slate-300 text-sm">
                Email: info@bakesbangpoldagri.ntbprov.go.id<br />
                Telp: (0370) XXXXXXX
              </p>
            </div>
          </div>
          <div className="border-t border-slate-700 mt-8 pt-6 text-center text-slate-400 text-sm">
            © {new Date().getFullYear()} BAKESBANGPOLDAGRI NTB. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
