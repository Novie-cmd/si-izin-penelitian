'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Upload, FileText, CheckCircle2, AlertCircle, Home } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

export default function PengajuanPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const [nomorRegistrasi, setNomorRegistrasi] = useState('')

  const [formData, setFormData] = useState({
    namaLengkap: '',
    nik: '',
    email: '',
    noHp: '',
    instansi: '',
    programStudi: '',
    judulPenelitian: '',
    lokasiPenelitian: '',
    tanggalMulai: '',
    tanggalSelesai: '',
    fileProposal: null as File | null,
    fileKtp: null as File | null,
    filePengantar: null as File | null,
  })

  const handleFileChange = (field: string, file: File | null) => {
    setFormData((prev) => ({ ...prev, [field]: file }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const formDataToSend = new FormData()
      Object.entries(formData).forEach(([key, value]) => {
        if (value instanceof File) {
          formDataToSend.append(key, value)
        } else {
          formDataToSend.append(key, value as string)
        }
      })

      const response = await fetch('/api/permohonan', {
        method: 'POST',
        body: formDataToSend,
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Gagal mengajukan permohonan')
      }

      setNomorRegistrasi(data.nomorRegistrasi)
      setSuccess(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan')
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
        <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" className="text-white hover:bg-white/10">
                  <Home className="w-4 h-4 mr-2" />
                  Beranda
                </Button>
              </Link>
              <h1 className="text-xl font-bold">Pengajuan Izin Penelitian</h1>
            </div>
          </div>
        </header>

        <main className="flex-1 container mx-auto px-4 py-12">
          <div className="max-w-2xl mx-auto">
            <Card className="border-2 border-green-500">
              <CardHeader className="text-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-10 h-10 text-green-600" />
                </div>
                <CardTitle className="text-2xl text-green-600">Permohonan Berhasil!</CardTitle>
                <CardDescription className="text-base">
                  Permohonan izin penelitian Anda telah berhasil disubmit
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="bg-blue-50 border-blue-200">
                  <FileText className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    <strong>Nomor Registrasi Anda:</strong>
                  </AlertDescription>
                  <div className="mt-2 p-4 bg-white rounded-lg border-2 border-blue-300 text-center">
                    <p className="text-2xl font-mono font-bold text-blue-900">{nomorRegistrasi}</p>
                  </div>
                  <AlertDescription className="text-blue-800 mt-2">
                    Simpan nomor registrasi ini untuk mengecek status permohonan Anda
                  </AlertDescription>
                </Alert>

                <div className="space-y-2 text-sm text-slate-600">
                  <p>• Status saat ini: <strong>Menunggu Verifikasi Admin</strong></p>
                  <p>• Anda akan menerima notifikasi email saat status berubah</p>
                  <p>• Pantau status permohonan Anda secara berkala</p>
                </div>

                <div className="flex gap-3 pt-4">
                  <Link href="/tracking" className="flex-1">
                    <Button className="w-full" variant="outline">
                      Cek Status Sekarang
                    </Button>
                  </Link>
                  <Link href="/" className="flex-1">
                    <Button className="w-full bg-blue-900 hover:bg-blue-800">
                      Kembali ke Beranda
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>

        <footer className="bg-slate-900 text-white mt-auto py-6">
          <div className="container mx-auto px-4 text-center text-slate-400 text-sm">
            © {new Date().getFullYear()} BAKESBANGPOLDAGRI NTB. All rights reserved.
          </div>
        </footer>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
      <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Kembali
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Form Pengajuan Izin Penelitian</h1>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Formulir Pengajuan Izin Penelitian</CardTitle>
              <CardDescription>
                Lengkapi semua data dan dokumen yang diperlukan untuk pengajuan izin penelitian
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {/* Data Diri */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800 border-b pb-2">
                    Data Diri Pemohon
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="namaLengkap">Nama Lengkap *</Label>
                      <Input
                        id="namaLengkap"
                        required
                        value={formData.namaLengkap}
                        onChange={(e) => setFormData({ ...formData, namaLengkap: e.target.value })}
                        placeholder="Masukkan nama lengkap"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="nik">NIK *</Label>
                      <Input
                        id="nik"
                        required
                        pattern="[0-9]{16}"
                        maxLength={16}
                        value={formData.nik}
                        onChange={(e) => setFormData({ ...formData, nik: e.target.value })}
                        placeholder="16 digit NIK"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="email@contoh.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="noHp">No HP/WhatsApp *</Label>
                      <Input
                        id="noHp"
                        type="tel"
                        required
                        value={formData.noHp}
                        onChange={(e) => setFormData({ ...formData, noHp: e.target.value })}
                        placeholder="08xxxxxxxxxx"
                      />
                    </div>
                  </div>
                </div>

                {/* Data Akademik/Instansi */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800 border-b pb-2">
                    Data Akademik / Instansi
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="instansi">Instansi/Universitas *</Label>
                      <Input
                        id="instansi"
                        required
                        value={formData.instansi}
                        onChange={(e) => setFormData({ ...formData, instansi: e.target.value })}
                        placeholder="Nama universitas atau instansi"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="programStudi">Program Studi/Divisi *</Label>
                      <Input
                        id="programStudi"
                        required
                        value={formData.programStudi}
                        onChange={(e) => setFormData({ ...formData, programStudi: e.target.value })}
                        placeholder="Program studi atau divisi"
                      />
                    </div>
                  </div>
                </div>

                {/* Data Penelitian */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800 border-b pb-2">
                    Data Penelitian
                  </h3>
                  <div className="space-y-2">
                    <Label htmlFor="judulPenelitian">Judul Penelitian *</Label>
                    <Textarea
                      id="judulPenelitian"
                      required
                      value={formData.judulPenelitian}
                      onChange={(e) => setFormData({ ...formData, judulPenelitian: e.target.value })}
                      placeholder="Masukkan judul penelitian secara lengkap"
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lokasiPenelitian">Lokasi Penelitian *</Label>
                    <Textarea
                      id="lokasiPenelitian"
                      required
                      value={formData.lokasiPenelitian}
                      onChange={(e) => setFormData({ ...formData, lokasiPenelitian: e.target.value })}
                      placeholder="Jelaskan lokasi penelitian secara detail"
                      rows={2}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="tanggalMulai">Tanggal Mulai *</Label>
                      <Input
                        id="tanggalMulai"
                        type="date"
                        required
                        value={formData.tanggalMulai}
                        onChange={(e) => setFormData({ ...formData, tanggalMulai: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tanggalSelesai">Tanggal Selesai *</Label>
                      <Input
                        id="tanggalSelesai"
                        type="date"
                        required
                        value={formData.tanggalSelesai}
                        onChange={(e) => setFormData({ ...formData, tanggalSelesai: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                {/* Upload Dokumen */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg text-slate-800 border-b pb-2">
                    Dokumen Pendukung
                  </h3>
                  <Alert>
                    <Upload className="h-4 w-4" />
                    <AlertDescription>
                      Format yang diterima: PDF. Maksimal ukuran file: 5MB
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="fileProposal">Proposal Penelitian * (PDF)</Label>
                      <Input
                        id="fileProposal"
                        type="file"
                        accept=".pdf"
                        required
                        onChange={(e) => handleFileChange('fileProposal', e.target.files?.[0] || null)}
                        className="cursor-pointer"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fileKtp">KTP/KTM * (PDF)</Label>
                      <Input
                        id="fileKtp"
                        type="file"
                        accept=".pdf"
                        required
                        onChange={(e) => handleFileChange('fileKtp', e.target.files?.[0] || null)}
                        className="cursor-pointer"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="filePengantar">Surat Pengantar Kampus/Instansi * (PDF)</Label>
                      <Input
                        id="filePengantar"
                        type="file"
                        accept=".pdf"
                        required
                        onChange={(e) => handleFileChange('filePengantar', e.target.files?.[0] || null)}
                        className="cursor-pointer"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-900 hover:bg-blue-800"
                  >
                    {loading ? 'Mengirim...' : 'Kirim Permohonan'}
                  </Button>
                  <Link href="/" className="flex-1">
                    <Button type="button" variant="outline" className="w-full">
                      Batal
                    </Button>
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="bg-slate-900 text-white mt-auto py-6">
        <div className="container mx-auto px-4 text-center text-slate-400 text-sm">
          © {new Date().getFullYear()} BAKESBANGPOLDAGRI NTB. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
