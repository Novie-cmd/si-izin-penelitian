'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  LayoutDashboard,
  FileText,
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Filter,
  LogOut,
  User,
  Calendar,
  MapPin,
  Building2,
  Eye,
  Download,
  Check,
  X,
  AlertTriangle,
  Home,
  Menu,
  X as CloseIcon
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface Permohonan {
  id: string
  nomorRegistrasi: string
  namaLengkap: string
  email: string
  noHp: string
  instansi: string
  programStudi: string
  judulPenelitian: string
  lokasiPenelitian: string
  tanggalMulai: string
  tanggalSelesai: string
  status: string
  fileProposal: string
  fileKtp: string
  filePengantar: string
  catatanAdmin?: string
  createdAt: string
}

interface DashboardStats {
  total: number
  disetujui: number
  ditolak: number
  menunggu: number
  menungguPersetujuan: number
}

export default function AdminDashboard() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [permohonan, setPermohonan] = useState<Permohonan[]>([])
  const [stats, setStats] = useState<DashboardStats>({
    total: 0,
    disetujui: 0,
    ditolak: 0,
    menunggu: 0,
    menungguPersetujuan: 0,
  })
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedPermohonan, setSelectedPermohonan] = useState<Permohonan | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [verifLoading, setVerifLoading] = useState(false)
  const [catatan, setCatatan] = useState('')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login')
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== 'ADMIN') {
        localStorage.removeItem('token')
        localStorage.removeItem('user')
        router.push('/login')
        return
      }

      setUser(parsedUser)
      fetchData()
    } catch (error) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      router.push('/login')
    }
  }, [router])

  const fetchData = async () => {
    try {
      const response = await fetch('/api/admin/permohonan')
      const data = await response.json()
      if (response.ok) {
        setPermohonan(data.permohonan || [])
        setStats(data.stats || {
          total: 0,
          disetujui: 0,
          ditolak: 0,
          menunggu: 0,
          menungguPersetujuan: 0,
        })
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    router.push('/login')
  }

  const handleVerifikasi = async (action: 'approve' | 'reject') => {
    if (!selectedPermohonan) return

    setVerifLoading(true)
    try {
      const response = await fetch(`/api/admin/permohonan/${selectedPermohonan.id}/verifikasi`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action,
          catatan: catatan,
        }),
      })

      if (!response.ok) throw new Error('Gagal memproses verifikasi')

      setDialogOpen(false)
      setCatatan('')
      setSelectedPermohonan(null)
      fetchData()
    } catch (error) {
      console.error('Error:', error)
      alert('Terjadi kesalahan saat memproses verifikasi')
    } finally {
      setVerifLoading(false)
    }
  }

  const filteredPermohonan = permohonan.filter((p) => {
    const matchesSearch =
      p.namaLengkap.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.nomorRegistrasi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.judulPenelitian.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.instansi.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === 'all' || p.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'MENUNGGU_VERIFIKASI':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'MENUNGGU_PERSETUJUAN':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'DISETUJUI':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'DITOLAK':
        return 'bg-red-100 text-red-800 border-red-200'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'MENUNGGU_VERIFIKASI':
        return 'Menunggu Verifikasi'
      case 'MENUNGGU_PERSETUJUAN':
        return 'Menunggu Persetujuan'
      case 'DISETUJUI':
        return 'Disetujui'
      case 'DITOLAK':
        return 'Ditolak'
      default:
        return status
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900 mx-auto mb-4"></div>
          <p className="text-slate-600">Memuat dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
      <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                className="lg:hidden text-white hover:bg-white/10"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <CloseIcon className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
              <LayoutDashboard className="w-6 h-6" />
              <div>
                <h1 className="text-xl font-bold">Dashboard Admin</h1>
                <p className="text-blue-100 text-sm">BAKESBANGPOLDAGRI NTB</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="hidden md:inline text-sm text-blue-100">
                {user?.nama}
              </span>
              <Button
                variant="outline"
                size="sm"
                className="bg-white/10 hover:bg-white/20 text-white border-white/30"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                <span className="hidden md:inline">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <aside className={`lg:col-span-1 ${mobileMenuOpen ? 'block' : 'hidden lg:block'}`}>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Menu</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/admin/dashboard">
                  <Button variant="ghost" className="w-full justify-start bg-blue-100 text-blue-900">
                    <LayoutDashboard className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                </Link>
                <Link href="/">
                  <Button variant="ghost" className="w-full justify-start text-slate-600 hover:text-slate-900">
                    <Home className="w-4 h-4 mr-2" />
                    Ke Beranda
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </aside>

          <main className="lg:col-span-3 space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              <Card className="border-t-4 border-t-blue-900">
                <CardHeader className="pb-3">
                  <CardDescription className="text-sm">Total Permohonan</CardDescription>
                  <CardTitle className="text-3xl">{stats.total}</CardTitle>
                </CardHeader>
              </Card>
              <Card className="border-t-4 border-t-yellow-500">
                <CardHeader className="pb-3">
                  <CardDescription className="text-sm">Menunggu Verifikasi</CardDescription>
                  <CardTitle className="text-3xl text-yellow-600">{stats.menunggu}</CardTitle>
                </CardHeader>
              </Card>
              <Card className="border-t-4 border-t-blue-500">
                <CardHeader className="pb-3">
                  <CardDescription className="text-sm">Menunggu Persetujuan</CardDescription>
                  <CardTitle className="text-3xl text-blue-600">{stats.menungguPersetujuan}</CardTitle>
                </CardHeader>
              </Card>
              <Card className="border-t-4 border-t-green-500">
                <CardHeader className="pb-3">
                  <CardDescription className="text-sm">Disetujui</CardDescription>
                  <CardTitle className="text-3xl text-green-600">{stats.disetujui}</CardTitle>
                </CardHeader>
              </Card>
              <Card className="border-t-4 border-t-red-500">
                <CardHeader className="pb-3">
                  <CardDescription className="text-sm">Ditolak</CardDescription>
                  <CardTitle className="text-3xl text-red-600">{stats.ditolak}</CardTitle>
                </CardHeader>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <CardTitle>Daftar Permohonan</CardTitle>
                    <CardDescription>Kelola dan verifikasi permohonan izin penelitian</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <Input
                        placeholder="Cari..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-48"
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-40">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Status</SelectItem>
                        <SelectItem value="MENUNGGU_VERIFIKASI">Menunggu Verifikasi</SelectItem>
                        <SelectItem value="MENUNGGU_PERSETUJUAN">Menunggu Persetujuan</SelectItem>
                        <SelectItem value="DISETUJUI">Disetujui</SelectItem>
                        <SelectItem value="DITOLAK">Ditolak</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-x-auto max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>No. Reg</TableHead>
                        <TableHead>Nama</TableHead>
                        <TableHead className="hidden md:table-cell">Instansi</TableHead>
                        <TableHead className="hidden lg:table-cell">Judul</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPermohonan.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                            Tidak ada data permohonan
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredPermohonan.map((p) => (
                          <TableRow key={p.id}>
                            <TableCell className="font-medium font-mono text-sm">
                              {p.nomorRegistrasi}
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="font-medium">{p.namaLengkap}</p>
                                <p className="text-xs text-slate-500">{p.email}</p>
                              </div>
                            </TableCell>
                            <TableCell className="hidden md:table-cell">
                              <div className="flex items-center gap-2">
                                <Building2 className="w-4 h-4 text-slate-400" />
                                <span className="text-sm">{p.instansi}</span>
                              </div>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell max-w-xs truncate">
                              {p.judulPenelitian}
                            </TableCell>
                            <TableCell>
                              <Badge className={getStatusColor(p.status)}>
                                {getStatusText(p.status)}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedPermohonan(p)
                                      setCatatan('')
                                    }}
                                  >
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                {selectedPermohonan && (
                                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                                    <DialogHeader>
                                      <DialogTitle>Detail Permohonan</DialogTitle>
                                      <DialogDescription>
                                        Nomor Registrasi: {selectedPermohonan.nomorRegistrasi}
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="space-y-4 py-4">
                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                          <Label>Nama Lengkap</Label>
                                          <p className="font-medium">{selectedPermohonan.namaLengkap}</p>
                                        </div>
                                        <div>
                                          <Label>Email</Label>
                                          <p className="font-medium">{selectedPermohonan.email}</p>
                                        </div>
                                        <div>
                                          <Label>No HP</Label>
                                          <p className="font-medium">{selectedPermohonan.noHp}</p>
                                        </div>
                                        <div>
                                          <Label>NIK</Label>
                                          <p className="font-medium">{selectedPermohonan.nik}</p>
                                        </div>
                                        <div>
                                          <Label>Instansi</Label>
                                          <p className="font-medium">{selectedPermohonan.instansi}</p>
                                        </div>
                                        <div>
                                          <Label>Program Studi</Label>
                                          <p className="font-medium">{selectedPermohonan.programStudi}</p>
                                        </div>
                                      </div>

                                      <div>
                                        <Label>Judul Penelitian</Label>
                                        <p className="font-medium">{selectedPermohonan.judulPenelitian}</p>
                                      </div>

                                      <div>
                                        <Label>Lokasi Penelitian</Label>
                                        <p className="font-medium">{selectedPermohonan.lokasiPenelitian}</p>
                                      </div>

                                      <div className="grid grid-cols-2 gap-4">
                                        <div>
                                          <Label>Tanggal Mulai</Label>
                                          <p className="font-medium">
                                            {new Date(selectedPermohonan.tanggalMulai).toLocaleDateString('id-ID')}
                                          </p>
                                        </div>
                                        <div>
                                          <Label>Tanggal Selesai</Label>
                                          <p className="font-medium">
                                            {new Date(selectedPermohonan.tanggalSelesai).toLocaleDateString('id-ID')}
                                          </p>
                                        </div>
                                      </div>

                                      <div>
                                        <Label>File Dokumen</Label>
                                        <div className="space-y-2 mt-2">
                                          <a
                                            href={`/uploads/${selectedPermohonan.fileProposal}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center gap-2 text-blue-600 hover:underline text-sm"
                                          >
                                            <FileText className="w-4 h-4" />
                                            Proposal Penelitian
                                          </a>
                                          <a
                                            href={`/uploads/${selectedPermohonan.fileKtp}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center gap-2 text-blue-600 hover:underline text-sm"
                                          >
                                            <FileText className="w-4 h-4" />
                                            KTP/KTM
                                          </a>
                                          <a
                                            href={`/uploads/${selectedPermohonan.filePengantar}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center gap-2 text-blue-600 hover:underline text-sm"
                                          >
                                            <FileText className="w-4 h-4" />
                                            Surat Pengantar
                                          </a>
                                        </div>
                                      </div>

                                      {selectedPermohonan.status === 'MENUNGGU_VERIFIKASI' && (
                                        <div className="space-y-2 pt-4 border-t">
                                          <Label htmlFor="catatan">Catatan (Opsional)</Label>
                                          <Textarea
                                            id="catatan"
                                            placeholder="Masukkan catatan untuk pemohon..."
                                            value={catatan}
                                            onChange={(e) => setCatatan(e.target.value)}
                                            rows={3}
                                          />
                                        </div>
                                      )}

                                      {selectedPermohonan.catatanAdmin && (
                                        <Alert>
                                          <AlertTriangle className="h-4 w-4" />
                                          <AlertDescription>
                                            <strong>Catatan Admin:</strong> {selectedPermohonan.catatanAdmin}
                                          </AlertDescription>
                                        </Alert>
                                      )}
                                    </div>
                                    <DialogFooter>
                                      {selectedPermohonan.status === 'MENUNGGU_VERIFIKASI' ? (
                                        <>
                                          <Button
                                            variant="outline"
                                            onClick={() => handleVerifikasi('reject')}
                                            disabled={verifLoading}
                                            className="bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700"
                                          >
                                            <X className="w-4 h-4 mr-2" />
                                            Tolak
                                          </Button>
                                          <Button
                                            onClick={() => handleVerifikasi('approve')}
                                            disabled={verifLoading}
                                            className="bg-green-600 hover:bg-green-700"
                                          >
                                            <Check className="w-4 h-4 mr-2" />
                                            Verifikasi & Kirim
                                          </Button>
                                        </>
                                      ) : (
                                        <Button variant="outline" onClick={() => setDialogOpen(false)}>
                                          Tutup
                                        </Button>
                                      )}
                                    </DialogFooter>
                                  </DialogContent>
                                )}
                              </Dialog>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>

      <footer className="bg-slate-900 text-white mt-auto py-6">
        <div className="container mx-auto px-4 text-center text-slate-400 text-sm">
          © {new Date().getFullYear()} BAKESBANGPOLDAGRI NTB. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
