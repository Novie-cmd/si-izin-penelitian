'use client'

import { useState } from 'react'
import Link from 'next/link'
import { SearchCheck, Clock, CheckCircle2, XCircle, AlertCircle, Home, Download, Calendar, MapPin, FileText, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'

interface PermohonanData {
  id: string
  nomorRegistrasi: string
  namaLengkap: string
  judulPenelitian: string
  instansi: string
  lokasiPenelitian: string
  tanggalMulai: string
  tanggalSelesai: string
  status: string
  catatanAdmin?: string
  catatanPimpinan?: string
  nomorSurat?: string
  tanggalApprove?: string
  createdAt: string
}

export default function TrackingPage() {
  const [nomorRegistrasi, setNomorRegistrasi] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [data, setData] = useState<PermohonanData | null>(null)

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!nomorRegistrasi.trim()) {
      setError('Masukkan nomor registrasi')
      return
    }

    setLoading(true)
    setError('')

    try {
      const response = await fetch(`/api/permohonan/${nomorRegistrasi}`)
      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Data tidak ditemukan')
      }

      setData(result)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan')
      setData(null)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'MENUNGGU_VERIFIKASI':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'MENUNGGU_PERSETUJUAN':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'DISETUJUI':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'DITOLAK':
        return 'bg-red-100 text-red-800 border-red-200'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'MENUNGGU_VERIFIKASI':
      case 'MENUNGGU_PERSETUJUAN':
        return <Clock className="w-5 h-5" />
      case 'DISETUJUI':
        return <CheckCircle2 className="w-5 h-5" />
      case 'DITOLAK':
        return <XCircle className="w-5 h-5" />
      default:
        return <AlertCircle className="w-5 h-5" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'MENUNGGU_VERIFIKASI':
        return 'Menunggu Verifikasi Admin'
      case 'MENUNGGU_PERSETUJUAN':
        return 'Menunggu Persetujuan Pimpinan'
      case 'DISETUJUI':
        return 'Disetujui'
      case 'DITOLAK':
        return 'Ditolak'
      default:
        return status
    }
  }

  const handleDownload = async () => {
    if (!data?.nomorSurat) return
    try {
      const response = await fetch(`/api/permohonan/${data.nomorRegistrasi}/download`)
      if (!response.ok) throw new Error('Gagal download surat')

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `surat-izin-${data.nomorRegistrasi}.pdf`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (err) {
      console.error('Download error:', err)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
      <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10">
                <Home className="w-4 h-4 mr-2" />
                Beranda
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Tracking Status Permohonan</h1>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <SearchCheck className="w-6 h-6 text-blue-900" />
                Cek Status Permohonan
              </CardTitle>
              <CardDescription>
                Masukkan nomor registrasi yang Anda dapatkan saat mengajukan permohonan
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSearch} className="flex gap-3">
                <div className="flex-1">
                  <Input
                    placeholder="Masukkan Nomor Registrasi"
                    value={nomorRegistrasi}
                    onChange={(e) => setNomorRegistrasi(e.target.value)}
                    className="text-lg"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-900 hover:bg-blue-800"
                >
                  {loading ? 'Mencari...' : 'Cari'}
                </Button>
              </form>
              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {data && (
            <Card className="border-2">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <CardTitle>Detail Permohonan</CardTitle>
                    <CardDescription>Nomor Registrasi: {data.nomorRegistrasi}</CardDescription>
                  </div>
                  <Badge className={`${getStatusColor(data.status)} text-base px-4 py-2 flex items-center gap-2 w-fit`}>
                    {getStatusIcon(data.status)}
                    {getStatusText(data.status)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Status Progress */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-slate-800">Status Proses</h3>
                  <div className="space-y-3">
                    <div className={`flex items-center gap-3 p-3 rounded-lg ${['MENUNGGU_VERIFIKASI', 'MENUNGGU_PERSETUJUAN', 'DISETUJUI', 'DITOLAK'].includes(data.status) ? 'bg-green-50 border border-green-200' : 'bg-gray-50'}`}>
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                      <span className="font-medium">Pengajuan Permohonan</span>
                      <span className="ml-auto text-sm text-slate-500">
                        {new Date(data.createdAt).toLocaleDateString('id-ID')}
                      </span>
                    </div>
                    <div className={`flex items-center gap-3 p-3 rounded-lg ${['MENUNGGU_PERSETUJUAN', 'DISETUJUI', 'DITOLAK'].includes(data.status) ? 'bg-green-50 border border-green-200' : data.status === 'MENUNGGU_VERIFIKASI' ? 'bg-yellow-50 border border-yellow-200' : 'bg-gray-50'}`}>
                      {['MENUNGGU_PERSETUJUAN', 'DISETUJUI', 'DITOLAK'].includes(data.status) ? (
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                      ) : data.status === 'MENUNGGU_VERIFIKASI' ? (
                        <Clock className="w-5 h-5 text-yellow-600" />
                      ) : (
                        <Clock className="w-5 h-5 text-gray-400" />
                      )}
                      <span className="font-medium">Verifikasi Admin</span>
                    </div>
                    <div className={`flex items-center gap-3 p-3 rounded-lg ${data.status === 'DISETUJUI' || data.status === 'DITOLAK' ? 'bg-green-50 border border-green-200' : data.status === 'MENUNGGU_PERSETUJUAN' ? 'bg-yellow-50 border border-yellow-200' : 'bg-gray-50'}`}>
                      {data.status === 'DISETUJUI' || data.status === 'DITOLAK' ? (
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                      ) : data.status === 'MENUNGGU_PERSETUJUAN' ? (
                        <Clock className="w-5 h-5 text-yellow-600" />
                      ) : (
                        <Clock className="w-5 h-5 text-gray-400" />
                      )}
                      <span className="font-medium">Persetujuan Pimpinan</span>
                    </div>
                    {data.status === 'DISETUJUI' && (
                      <div className="flex items-center gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                        <span className="font-medium">Surat Izin Diterbitkan</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Informasi Pemohon */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-slate-800">Informasi Pemohon</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3">
                      <User className="w-5 h-5 text-slate-400 mt-0.5" />
                      <div>
                        <p className="text-sm text-slate-500">Nama Lengkap</p>
                        <p className="font-medium">{data.namaLengkap}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <FileText className="w-5 h-5 text-slate-400 mt-0.5" />
                      <div>
                        <p className="text-sm text-slate-500">Instansi</p>
                        <p className="font-medium">{data.instansi}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Informasi Penelitian */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-slate-800">Informasi Penelitian</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <FileText className="w-5 h-5 text-slate-400 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-500">Judul Penelitian</p>
                        <p className="font-medium">{data.judulPenelitian}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-slate-400 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-500">Lokasi Penelitian</p>
                        <p className="font-medium">{data.lokasiPenelitian}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Calendar className="w-5 h-5 text-slate-400 mt-0.5" />
                      <div>
                        <p className="text-sm text-slate-500">Waktu Penelitian</p>
                        <p className="font-medium">
                          {new Date(data.tanggalMulai).toLocaleDateString('id-ID')} -{' '}
                          {new Date(data.tanggalSelesai).toLocaleDateString('id-ID')}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Catatan */}
                {(data.catatanAdmin || data.catatanPimpinan) && (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-slate-800">Catatan</h3>
                    {data.catatanAdmin && (
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Catatan Admin:</strong> {data.catatanAdmin}
                        </AlertDescription>
                      </Alert>
                    )}
                    {data.catatanPimpinan && (
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Catatan Pimpinan:</strong> {data.catatanPimpinan}
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                )}

                {/* Download Surat */}
                {data.status === 'DISETUJUI' && data.nomorSurat && (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-slate-800">Surat Izin</h3>
                    <Alert className="bg-green-50 border-green-200">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800">
                        <div className="flex items-center justify-between">
                          <div>
                            <strong>Surat Izin telah diterbitkan!</strong><br />
                            <span className="text-sm">Nomor Surat: {data.nomorSurat}</span>
                          </div>
                          <Button onClick={handleDownload} className="bg-green-600 hover:bg-green-700">
                            <Download className="w-4 h-4 mr-2" />
                            Download Surat
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  </div>
                )}

                <div className="pt-4">
                  <Link href="/">
                    <Button variant="outline" className="w-full">
                      Kembali ke Beranda
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      <footer className="bg-slate-900 text-white mt-auto py-6">
        <div className="container mx-auto px-4 text-center text-slate-400 text-sm">
          © {new Date().getFullYear()} BAKESBANGPOLDAGRI NTB. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
