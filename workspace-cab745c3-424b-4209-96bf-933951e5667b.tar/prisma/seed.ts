import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('Starting seed...')

  // Create Admin User
  const adminPassword = await bcrypt.hash('admin123', 10)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@bakesbang.ntbprov.go.id' },
    update: {},
    create: {
      email: 'admin@bakesbang.ntbprov.go.id',
      password: adminPassword,
      nama: 'Admin Bakesbang',
      role: 'ADMIN',
    },
  })
  console.log('Created admin user:', admin.email)

  // Create Pimpinan User
  const pimpinanPassword = await bcrypt.hash('pimpinan123', 10)
  const pimpinan = await prisma.user.upsert({
    where: { email: 'pimpinan@bakesbang.ntbprov.go.id' },
    update: {},
    create: {
      email: 'pimpinan@bakesbang.ntbprov.go.id',
      password: pimpinanPassword,
      nama: 'Kepala Bakesbang',
      role: 'PIMPINAN',
    },
  })
  console.log('Created pimpinan user:', pimpinan.email)

  console.log('Seed completed!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
